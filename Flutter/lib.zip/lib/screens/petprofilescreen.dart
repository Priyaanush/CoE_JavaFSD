import 'package:flutter/material.dart';

class PetProfileScreen extends StatefulWidget {
  @override
  _PetProfileScreenState createState() => _PetProfileScreenState();
}

class _PetProfileScreenState extends State<PetProfileScreen> {
  String _petType = 'Cat'; // Default pet type
  String _breed = '';
  String _allergies = '';
  String _ownerContact = '';
  String _adoptionDate = '';
  String _adoptionSource = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pet Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView( // To prevent overflow on small screens
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Pet Type',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              DropdownButton<String>(
                value: _petType,
                onChanged: (String? newValue) {
                  setState(() {
                    _petType = newValue!;
                  });
                },
                items: <String>['Cat', 'Dog', 'Bird', 'Other']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              SizedBox(height: 16),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Breed',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    _breed = value;
                  });
                },
              ),
              SizedBox(height: 16),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Allergies & Special Conditions',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    _allergies = value;
                  });
                },
              ),
              SizedBox(height: 16),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Owner Contact Number',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
                onChanged: (value) {
                  setState(() {
                    _ownerContact = value;
                  });
                },
              ),
              SizedBox(height: 16),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Adoption Date',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    _adoptionDate = value;
                  });
                },
              ),
              SizedBox(height: 16),
              TextField(
                decoration: InputDecoration(
                  labelText: 'Adoption Source',
                  border: OutlineInputBorder(),
                ),
                onChanged: (value) {
                  setState(() {
                    _adoptionSource = value;
                  });
                },
              ),
              SizedBox(height: 24),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    // Implement save profile logic here
                    print('Pet Type: $_petType');
                    print('Breed: $_breed');
                    print('Allergies: $_allergies');
                    print('Owner Contact: $_ownerContact');
                    print('Adoption Date: $_adoptionDate');
                    print('Adoption Source: $_adoptionSource');
                    // You can save the data to a database or local storage
                  },
                  child: Text('Save Profile'),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 50, vertical: 15),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
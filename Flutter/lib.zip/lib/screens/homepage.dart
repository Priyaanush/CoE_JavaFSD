import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pet Care Hub'),
        actions: [
          TextButton(
            onPressed: () {
              // Implement language selection logic here
            },
            child: Row(
              children: [
                Text('English'),
                Icon(Icons.language),
              ],
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.count(
          crossAxisCount: 2,
          children: <Widget>[
            _buildGridItem(context, 'Pet Profile', Icons.pets, '/pet_profile'),
            _buildGridItem(context, 'Veterinary Services', Icons.local_hospital, '/veterinary_services'),
            _buildGridItem(context, 'Grooming & Training', Icons.content_cut, '/grooming_training'),
            _buildGridItem(context, 'Pet Products Store', Icons.shopping_cart, '/pet_store'),
            _buildGridItem(context, 'Adoption Center', Icons.favorite, '/adoption_center'),
            _buildGridItem(context, 'Lost & Found', Icons.search, '/lost_found'),
            _buildGridItem(context, 'Community Forum', Icons.forum, '/community_forum'),
            _buildGridItem(context, 'Emergency Contacts', Icons.phone, '/emergency_contacts'),
          ],
        ),
      ),
    );
  }

  Widget _buildGridItem(BuildContext context, String title, IconData icon, String route) {
    return Card(
      child: InkWell(
        onTap: () {
          Navigator.pushNamed(context, route);
        },
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(icon, size: 40.0, color: Colors.teal), // You can customize the color
              SizedBox(height: 10.0),
              Text(title, textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
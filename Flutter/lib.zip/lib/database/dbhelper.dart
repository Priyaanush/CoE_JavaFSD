// dbhelper.dart

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBHelper {
  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'petcare_database.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDatabase,
    );
  }

  Future<void> _createDatabase(Database db, int version) async {
    // Create tables here
    await db.execute('''
      CREATE TABLE pet_profiles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        breed TEXT,
        age INTEGER,
        ownerName TEXT,
        contactNumber TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE lost_found_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        petType TEXT,
        description TEXT,
        location TEXT,
        contactNumber TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE community_posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        content TEXT,
        author TEXT,
        timestamp INTEGER
      )
    ''');

    // Add other tables as needed (veterinary services, grooming, etc.)
  }

  // Pet Profiles Operations
  Future<int> insertPetProfile(Map<String, dynamic> petProfile) async {
    final db = await database;
    return await db.insert('pet_profiles', petProfile);
  }

  Future<List<Map<String, dynamic>>> getPetProfiles() async {
    final db = await database;
    return await db.query('pet_profiles');
  }

  Future<int> updatePetProfile(Map<String, dynamic> petProfile, int id) async {
    final db = await database;
    return await db.update('pet_profiles', petProfile, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> deletePetProfile(int id) async {
    final db = await database;
    return await db.delete('pet_profiles', where: 'id = ?', whereArgs: [id]);
  }

  // Lost & Found Reports Operations
  Future<int> insertLostFoundReport(Map<String, dynamic> report) async {
    final db = await database;
    return await db.insert('lost_found_reports', report);
  }

  Future<List<Map<String, dynamic>>> getLostFoundReports() async {
    final db = await database;
    return await db.query('lost_found_reports');
  }

  // Community Posts Operations
  Future<int> insertCommunityPost(Map<String, dynamic> post) async {
    final db = await database;
    return await db.insert('community_posts', post);
  }

  Future<List<Map<String, dynamic>>> getCommunityPosts() async {
    final db = await database;
    return await db.query('community_posts');
  }

  // Add methods for other tables (veterinary services, grooming, etc.) here...

  Future<void> close() async {
    final db = await database;
    db.close();
  }
}
import 'package:flutter/material.dart';

class PetProductsStoreScreen extends StatelessWidget {
  final List<Map<String, dynamic>> products = [
    {
      'name': 'Dog Food',
      'price': 20,
    },
    {
      'name': 'Cat Food',
      'price': 18,
    },
    {
      'name': 'Chew Toy',
      'price': 8,
    },
    {
      'name': 'Litter Box',
      'price': 25,
    },
    {
      'name': 'Pet Shampoo',
      'price': 10,
    },
    {
      'name': 'Scratching Post',
      'price': 30,
    },
    {
      'name': 'Leash & Collar',
      'price': 15,
    },
    {
      'name': 'Pet Bed',
      'price': 40,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pet Products Store'),
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, // 2 columns
          childAspectRatio: 1, // Adjust as needed
        ),
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  product['name'],
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8.0),
                Text('Rs ${product['price']}'),
                SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: () {
                    // Implement "Add to Cart" logic here
                    print('Added to Cart: ${product['name']}');
                    // Example: Add product to a cart list
                  },
                  child: Text('Add to Cart'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
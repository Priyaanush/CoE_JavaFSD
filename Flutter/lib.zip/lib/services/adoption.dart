import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AdoptionCentersScreen extends StatefulWidget {
  @override
  _AdoptionCentersScreenState createState() => _AdoptionCentersScreenState();
}

class _AdoptionCentersScreenState extends State<AdoptionCentersScreen> {
  List<Map<String, dynamic>> adoptionCenters = [];
  bool isLoading = true;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    fetchAdoptionCenters();
  }

  Future<void> fetchAdoptionCenters() async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    try {
      final response = await http.get(Uri.parse('YOUR_API_ENDPOINT_HERE')); // Replace with your API endpoint
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        setState(() {
          adoptionCenters = data.cast<Map<String, dynamic>>().toList();
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage = 'Failed to load adoption centers. Status code: ${response.statusCode}';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'An error occurred: $e';
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Nearby Adoption Centers'),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : errorMessage.isNotEmpty
              ? Center(child: Text(errorMessage))
              : ListView.builder(
                  itemCount: adoptionCenters.length,
                  itemBuilder: (context, index) {
                    final center = adoptionCenters[index];
                    return Card(
                      margin: EdgeInsets.all(8.0),
                      child: ListTile(
                        title: Text(center['name']),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Location: ${center['location']}'),
                            Text('Contact: ${center['contact']}'),
                          ],
                        ),
                        trailing: IconButton(
                          icon: Icon(Icons.phone),
                          onPressed: () {
                            // Implement phone call logic here
                            print('Call: ${center['contact']}');
                            // Example: launchUrl(Uri.parse('tel:${center['contact']}'));
                          },
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}
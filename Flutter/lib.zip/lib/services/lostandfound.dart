import 'package:flutter/material.dart';

class LostFoundScreen extends StatefulWidget {
  @override
  _LostFoundScreenState createState() => _LostFoundScreenState();
}

class _LostFoundScreenState extends State<LostFoundScreen> {
  String _petType = '';
  String _description = '';
  String _location = '';
  String _contactNumber = '';

  List<Map<String, String>> _reports = [];

  void _reportPet() {
    setState(() {
      _reports.add({
        'petType': _petType,
        'description': _description,
        'location': _location,
        'contactNumber': _contactNumber,
      });

      // Clear the form fields after reporting
      _petType = '';
      _description = '';
      _location = '';
      _contactNumber = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lost & Found'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextField(
              decoration: InputDecoration(labelText: 'Pet Type'),
              onChanged: (value) => setState(() => _petType = value),
            ),
            TextField(
              decoration: InputDecoration(labelText: 'Description'),
              onChanged: (value) => setState(() => _description = value),
            ),
            TextField(
              decoration: InputDecoration(labelText: 'Location'),
              onChanged: (value) => setState(() => _location = value),
            ),
            TextField(
              decoration: InputDecoration(labelText: 'Contact Number'),
              onChanged: (value) => setState(() => _contactNumber = value),
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _reportPet,
              child: Text('Report Pet'),
            ),
            SizedBox(height: 24.0),
            Text(
              'Lost & Found Reports',
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8.0),
            _reports.isEmpty
                ? Text('No reports yet.')
                : ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: _reports.length,
                    itemBuilder: (context, index) {
                      final report = _reports[index];
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text('Pet Type: ${report['petType']}'),
                              Text('Description: ${report['description']}'),
                              Text('Location: ${report['location']}'),
                              Text('Contact: ${report['contactNumber']}'),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ],
        ),
      ),
    );
  }
}
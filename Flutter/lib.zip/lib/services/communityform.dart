import 'package:flutter/material.dart';

class CommunityForumScreen extends StatelessWidget {
  final List<Map<String, String>> posts = [
    {
      'title': 'Best Training Tips for Puppies',
      'author': 'John Doe',
    },
    {
      'title': 'Recommended Diet for Senior Cats',
      'author': 'Sarah Lee',
    },
    {
      'title': 'Looking for a Good Vet in My Area',
      'author': 'Michael Brown',
    },
    {
      'title': 'How to Handle Pet Allergies?',
      'author': 'Emily Davis',
    },
    {
      'title': 'Fun Outdoor Activities with Dogs',
      'author': 'David Wilson',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Community Forum'),
      ),
      body: ListView.builder(
        itemCount: posts.length,
        itemBuilder: (context, index) {
          final post = posts[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              title: Text(post['title']!),
              subtitle: Text('By: ${post['author']}'),
              trailing: Icon(Icons.comment), // Comment icon
              onTap: () {
                // Implement navigation to post details or comments screen
                print('Tapped: ${post['title']}');
                // Example: Navigator.pushNamed(context, '/post_details', arguments: post);
              },
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Implement navigation to create a new post
          print('Create New Post');
          // Example: Navigator.pushNamed(context, '/create_post');
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
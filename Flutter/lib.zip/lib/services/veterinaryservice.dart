import 'package:flutter/material.dart';

class VeterinaryServicesScreen extends StatelessWidget {
  final List<Map<String, String>> services = [
    {
      'title': 'General Checkup',
      'description': 'Routine health checkup for your pet.',
    },
    {
      'title': 'Vaccination',
      'description': 'Essential vaccines to keep your pet healthy.',
    },
    {
      'title': 'Dental Care',
      'description': 'Teeth cleaning and dental treatment.',
    },
    {
      'title': 'Surgery',
      'description': 'Minor and major surgical procedures.',
    },
    {
      'title': 'Emergency Care',
      'description': '24/7 emergency medical support.',
    },
    {
      'title': 'Parasite Control',
      'description': 'Flea, tick, and worm treatments.',
    },
    {
      'title': 'Nutritional Counseling',
      'description': 'Expert advice on pet diet and nutrition.',
    },
    {
      'title': 'Pet Grooming',
      'description': 'Professional grooming services.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Veterinary Services'),
      ),
      body: ListView.builder(
        itemCount: services.length,
        itemBuilder: (context, index) {
          final service = services[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.teal, // Or any color you prefer
                child: Icon(Icons.add, color: Colors.white), // Plus icon
              ),
              title: Text(service['title']!),
              subtitle: Text(service['description']!),
              onTap: () {
                // Implement navigation or action for each service here
                print('Tapped: ${service['title']}');
                // Example: Navigator.pushNamed(context, '/service_details', arguments: service);
              },
            ),
          );
        },
      ),
    );
  }
}
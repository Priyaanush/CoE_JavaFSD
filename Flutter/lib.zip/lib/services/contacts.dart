import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart'; // Import for making phone calls

class EmergencyContactsScreen extends StatelessWidget {
  final List<Map<String, String>> contacts = [
    {
      'name': 'Veterinary Emergency',
      'number': '9876543210',
    },
    {
      'name': 'Animal Control',
      'number': '1234567890',
    },
    {
      'name': 'Pet Poison Helpline',
      'number': '800-213-6680',
    },
    {
      'name': 'Local Animal Shelter',
      'number': '555-678-9012',
    },
    {
      'name': 'Lost & Found Pets',
      'number': '444-123-5678',
    },
    {
      'name': '24/7 Vet Clinic',
      'number': '999-555-3333',
    },
    {
      'name': 'Pet Adoption Center',
      'number': '777-888-9999',
    },
    {
      'name': 'Pet Rescue Team',
      'number': '666-222-4444',
    },
    {
      'name': 'Wildlife Rescue',
      'number': '333-777-1111',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Emergency Contacts'),
      ),
      body: ListView.builder(
        itemCount: contacts.length,
        itemBuilder: (context, index) {
          final contact = contacts[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              title: Text(contact['name']!),
              subtitle: Text(contact['number']!),
              trailing: IconButton(
                icon: Icon(Icons.phone),
                onPressed: () async {
                  final Uri phoneUri = Uri(
                    scheme: 'tel',
                    path: contact['number'],
                  );
                  if (await canLaunchUrl(phoneUri)) {
                    await launchUrl(phoneUri);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Could not launch ${contact['number']}')),
                    );
                  }
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
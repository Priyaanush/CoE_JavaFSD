import 'package:flutter/material.dart';

class GroomingTrainingScreen extends StatelessWidget {
  final List<Map<String, dynamic>> services = [
    {
      'icon': Icons.cleaning_services,
      'title': 'Bathing & Cleaning',
      'description': 'Complete bathing and hygiene care for your pet.',
    },
    {
      'icon': Icons.content_cut,
      'title': 'Haircuts & Styling',
      'description': 'Professional grooming for different breeds.',
    },
    {
      'icon': Icons.pets,
      'title': 'Nail Clipping',
      'description': 'Safe and comfortable nail trimming service.',
    },
    {
      'icon': Icons.accessibility_new,
      'title': 'Obedience Training',
      'description': 'Basic and advanced training for pet behavior.',
    },
    {
      'icon': Icons.directions_run,
      'title': 'Agility Training',
      'description': 'Enhancing pet agility and fitness.',
    },
    {
      'icon': Icons.favorite,
      'title': 'Socialization Classes',
      'description': 'Training for better interaction with other pets and humans.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Grooming & Training'),
      ),
      body: ListView.builder(
        itemCount: services.length,
        itemBuilder: (context, index) {
          final service = services[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Row(
                children: <Widget>[
                  Icon(service['icon'], size: 40.0, color: Colors.teal),
                  SizedBox(width: 16.0),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          service['title'],
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 8.0),
                        Text(service['description']),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Implement "Book Now" logic here
                      print('Book Now: ${service['title']}');
                      // Example: Navigator.pushNamed(context, '/booking', arguments: service);
                    },
                    child: Text('Book Now'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
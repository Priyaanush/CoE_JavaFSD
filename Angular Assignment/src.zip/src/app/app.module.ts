import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginAndRegistrationComponent } from './common/login-and-registration/login-and-registration.component';
import { NavBarComponent } from './common/nav-bar/nav-bar.component';
import { RecipesComponent } from './pages/recipes/recipes.component';
import { RecipyComponent } from './pages/recipes/recipy/recipy.component';
import { SearchRecipeComponent } from './pages/search-recipe/search-recipe.component';
import { SearchItemsComponent } from './pages/search-recipe/search-items/search-items.component';
import { RecipeFilterPipe } from './pipes/recipe-filter.pipe';
import { ListComponent } from './pages/list/list.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginAndRegistrationComponent,
    NavBarComponent,
    RecipesComponent,
    RecipyComponent,
    SearchRecipeComponent,
    SearchItemsComponent,
    RecipeFilterPipe,
    ListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

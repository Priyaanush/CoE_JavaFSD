import { Pipe, PipeTransform } from '@angular/core';
import { Recipe } from '../models/recipe';

@Pipe({
  name: 'recipeFilter'
})
export class RecipeFilterPipe implements PipeTransform {

  transform(recipelist: Recipe[], recipename: string): Recipe[] {
    return recipelist.filter(recipe => recipe.name === recipename);
  }

}

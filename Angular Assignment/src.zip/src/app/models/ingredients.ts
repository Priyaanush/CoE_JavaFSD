export interface IngredientData {
    name: string;
    ingredients: any[]; // Change this to a more specific type if possible
  }
export interface Recipe {
bgColor: any;
name: string;
description: string;
ingredients: string[];
steps: string[];
image: string;
}
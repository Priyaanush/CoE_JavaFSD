import { Component } from '@angular/core';
import { ApiServicesService } from '../../services/api-services.service';
import { Recipe } from '../../models/recipe';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrl: './recipes.component.css'
})
export class RecipesComponent {
  recipelist: Recipe[] = [];
  constructor(private as:ApiServicesService) { }
  ngOnInit(): void {
    this.as.getRecipe().subscribe({
        next:(result:Recipe[])=>{this.recipelist=result},
        error:(err:any)=>{console.log(err)}
    })
}}

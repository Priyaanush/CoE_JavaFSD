import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router'; // Adjust the path if necessary
import { ApiServicesService } from '../../services/api-services.service';
import { Recipe } from '../../models/recipe';

@Component({
  selector: 'app-search-recipe',
  templateUrl: './search-recipe.component.html',
  styleUrl: './search-recipe.component.css'
})
export class SearchRecipeComponent {
  recipelist: Recipe[] = [];
  recipenames: string[] = [
    "Chocolate Cake",
    "Vanilla Cake",
    "Red Velvet Cake",
    "Carrot Cake",
    "Lemon Cake",
    "Marble Cake",
    "Coconut Cake",
    "Spice Cake",
    "Pound Cake",
    "Banana Cake"
  ];
  selected: string='Croissants';
  constructor(private as:ApiServicesService) { }
  ngOnInit(): void {
    this.as.getRecipe().subscribe({
        next:(result:Recipe[])=>{this.recipelist=result},
        error:(err:any)=>{console.log(err)}
    })
  }
}